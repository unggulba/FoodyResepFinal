package com.example.foody.ui
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

object RealTimeDatabase {
    fun instance() = firebase.database
}